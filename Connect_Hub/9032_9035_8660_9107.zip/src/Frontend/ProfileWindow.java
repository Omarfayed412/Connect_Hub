package Frontend;

import javax.swing.*;

public class ProfileWindow {

    private JPanel panel1;
}
