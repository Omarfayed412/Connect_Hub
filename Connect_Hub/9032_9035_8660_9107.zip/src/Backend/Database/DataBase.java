package Backend.Database;

// using this interface to apply Dependency inversion Principle
  interface Database {
    public void save();
    public void load();
   // public void numberOfJSONobjects();
 }
/*
user    content
Dat=Base userDateba  = new
 */