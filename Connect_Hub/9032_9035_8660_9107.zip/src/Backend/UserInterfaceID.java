package Backend;

public interface UserInterfaceID extends UserInterface {
    String getUserID();
    Profile getProfile();
}
